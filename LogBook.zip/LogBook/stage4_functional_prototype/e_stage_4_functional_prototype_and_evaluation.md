[Back to main Logbook Page](../hci_logbook.md)

---

# E. Functional Prototype and Evaluation

# Prototype

![main page with filters](image.png)
![product information](image-1.png)
![admin pov](image-2.png)
![carrinho de compras](image-5.png)
![aba de favoritos](image-6.png)



# E.X. User Evaluation

---
![user 1](image-3.png)
![user 2](image-4.png)
[Back to main Logbook Page](../hci_logbook.md)

---