[Back to main Logbook Page](../hci_logbook.md)

---

# Self-Evaluation and Workload

Nil Silva (25%) - 15
Luis Pereira (25%) - 16
Leonardo Luís (25%) - 17
Rodrigo Moço (25%) - 17




---
[Back to main Logbook Page](../hci_logbook.md)

---
