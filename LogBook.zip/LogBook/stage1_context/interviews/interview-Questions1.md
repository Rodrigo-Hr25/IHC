# Guião da Entrevista

## Objetivo da Entrevista
Entender a experiência do utilizador ao navegar na loja online da Universidade de Harvard e identificar desafios, expectativas e melhorias.

## Perguntas

1. **Qual é o objetivo principal que tentas alcançar ao visitar esta loja online?**
   - (Exemplo: Procurar produtos da Universidade de Harvard, comprar merchandise, etc.)
   verificar os itens da pagina inicial e navegfar os itens que quer. quando se esta a navegar ha diferenaças entre procurar extamanete uma coisa, e procurar no site caso tenha aparecido ao acaso.

2. **Quais são as maiores dificuldades ou frustrações que encontras ao usar a loja online?**
   - (Exemplo: Dificuldade em navegar, demora na página, falta de filtros, etc.)
   AParecer produtos que nao tem nada haver com que o utilizador procura. Quando há muita confusão e coisas ao mesmo tempo e produtos a mais ou nao relacionados com o que o utilziador quer

3. **Há algo que normalmente fazes para contornar esses problemas ou alguma estratégia que usas enquanto compras online?**
   - (Exemplo: Usar filtros externos, comparar preços em outras plataformas, etc.)
   - Utilizador usaria fultros para procurar o que quer e nao aparecer tantas coisas

4. **O que achas que a loja poderia melhorar para tornar a experiência de compra mais fácil ou agradável para ti?**
   - (Exemplo: Melhorar a navegação, otimizar o processo de pagamento, incluir reviews de outros utilizadores, etc.)
   Bons filtros é o mais importante, poucos itens e com filtros bons, porque ate pode ter poucas coisas, mas se os filtrso não são bons o utilizador não consegue encontrar o que procura.

5. **O que seria uma funcionalidade ideal ou recurso que gostarias de ver na loja online para melhorar a tua experiência?**
   - (Exemplo: Filtros avançados, descontos exclusivos, mais informações sobre os produtos, etc.)

6. **Utilizarias um site do DETI/UA de MErch?**
   - Faz sentido utilizar um sitio para agrupar tudo numa loja online, e o utlizador até gostaria de comprar merch do DETI e daria jeito por exemplo um rato, um mouse pad.
## Encerramento

- **Há mais alguma coisa que gostarias de acrescentar sobre a tua experiência com esta loja online?**
