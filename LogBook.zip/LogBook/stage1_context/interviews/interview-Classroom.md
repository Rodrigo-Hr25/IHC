
# Guião da Entrevista

## Objetivo da Entrevista
Entender a experiência do utilizador ao navegar na loja online da Universidade de Harvard e identificar desafios, expectativas e melhorias.

## Perguntas

1. **Qual é o objetivo principal que tentas alcançar ao visitar esta loja online?**
   - (Exemplo: Procurar produtos da Universidade de Harvard, comprar merchandise, etc.)

R1:SE PROCURAR SER DIFERENTES PRODUTOS VER O QUE ESTA MAIS BARATO IR SO VER SSE HA ALGUMA NOVIDADE E SE UTIL COMPRAR.

R2:

2. **Quais são as maiores dificuldades ou frustrações que encontras ao usar a loja online?**
   - (Exemplo: Dificuldade em navegar, demora na página, falta de filtros, etc.)

R1: [ENCONTAR O MODELO ESPECIFICO DA PECA QUE QUER] 

[QDO HA MUITAS CATEGORIAS DE ITENS É DIFICIL ENCONTRAR O QUE SE PRETENDE]

R2:

3. **Há algo que normalmente fazes para contornar esses problemas ou alguma estratégia que usas enquanto compras online?**
   - (Exemplo: Usar filtros externos, comparar preços em outras plataformas, etc.)

R1: UTILIZAR SITES DE COMPARACAO DE PRODUTOS EM SITES DIFERENTES 

UTILIZAR FILTROS PRA DIMINUIR A SEARCH

UTILIZAR SITES DE REVIEWS E COMPARAR OS PRODUTOS QUE SE PRETENDE COMPRAR

R2:

4. **O que achas que a loja poderia melhorar para tornar a experiência de compra mais fácil ou agradável para ti?**
   - (Exemplo: Melhorar a navegação, otimizar o processo de pagamento, incluir reviews de outros utilizadores, etc.)

R1: QDO PESQUISAR POR UM ITEM MOSTRAR LOGO ITENS SEMELHANTES

R2:

5. **O que seria uma funcionalidade ideal ou recurso que gostarias de ver na loja online para melhorar a tua experiência?**
   - (Exemplo: Filtros avançados, descontos exclusivos, mais informações sobre os produtos, etc.)

R1: MAIS INFORMACOES SOBRE PRODUTOS

R2:

## Encerramento

- **Há mais alguma coisa que gostarias de acrescentar sobre a tua experiência com esta loja online?**

R1: NAO

R2: