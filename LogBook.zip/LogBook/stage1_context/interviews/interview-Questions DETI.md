# Guião da Entrevista

## Objetivo da Entrevista
Entender a experiência do utilizador ao navegar na loja online da Universidade de Harvard e identificar desafios, expectativas e melhorias.

## Perguntas

1. **Qual é o objetivo principal que tentas alcançar ao visitar esta loja online?**
   - (Exemplo: Procurar produtos da Universidade de Harvard, comprar merchandise, etc.)
   Se o utilzador estiver à procura de algo, por exemplo uma ssapatilhas, pesquisa no google e dentro do site, ia escolher por categoria sapatilhas de homem, corrida e depois aí procuravas. Ter uma opção de promoções ajudaria, e sentia-se tentar a clicar. Se as sapatilhas tivessem em promoção e tivesse em duvida entre duas, uma que esta em promoçãoe  outras nao, iria para as que estao em promoção mas antes iria ver reviews no youtube. As reviews de um produto importam.

2. **Quais são as maiores dificuldades ou frustrações que encontras ao usar a loja online?**
   - (Exemplo: Dificuldade em navegar, demora na página, falta de filtros, etc.)
   O utiliador diria que o metodo de pagamento é muito importante, se nao for facil e rapido o utlzador abandona a ideia de comprar e vai procurar a outr lado, tem de ser facil, moderno e minimalista. Um site manhoso da a ideia de scam.

3. **Há algo que normalmente fazes para contornar esses problemas ou alguma estratégia que usas enquanto compras online?**
   - (Exemplo: Usar filtros externos, comparar preços em outras plataformas, etc.)
   - O utilziador gostaria de comparar o preço, e/ou saber que se encontra no website com o melhor produto e mais barato da concorrência.

4. **O que achas que a loja poderia melhorar para tornar a experiência de compra mais fácil ou agradável para ti?**
   - (Exemplo: Melhorar a navegação, otimizar o processo de pagamento, incluir reviews de outros utilizadores, etc.)
   Nao ter mutio anuncios, ter um suporto de ajuda fidedigno e boas reviews a cima de tudo.

6. **Utilizarias um site do DETI/UA de MErch?**
   -  O utlizador gostava de ver uma merch so do deti, pois cada curso que poderia ter varios estilos para cada curso. O utilziador comrpou uma merch da AAUAV mas o tamanho XL nao corresponde, e diz que memso sendo mais caro ate preferia. Se aparece-se um anuncio 100% de certeza clicava e iria explorar. Iria comprar uma merch com o nome do curso, casacos, quispo de CT sente falta disso. Autovolantes, porta-chaves. Utilizaria no compuatdor.
## Encerramento

- **Há mais alguma coisa que gostarias de acrescentar sobre a tua experiência com esta loja online?**
