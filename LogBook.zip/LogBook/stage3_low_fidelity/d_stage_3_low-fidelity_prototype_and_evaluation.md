

---
# Low Fidelity Prototype and Evaluation

## D.1. Low Fidelity Prototype


## D.2. Prototype Evaluation

During the prototype evaluation, the major problem was the lack of "go back buttons". Also the users found it hard to join the contests and also to vote on the designs.
While in admin mode, users thought that we should be more clear on how to manage the stock. Finally, the users thought that having two buttons, one to add an item to cart and other to immediately purchase, was creating some kind of confusion.

---
[Back to main Logbook Page](../hci_logbook.md)

---
